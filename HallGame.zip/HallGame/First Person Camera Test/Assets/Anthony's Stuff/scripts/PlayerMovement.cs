﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerMovement : MonoBehaviour
{
    public CharacterController controller;
    public float speed = 12f;
    public float RSpeed = 18f;
    public float RunEnergy;
    public bool run;
    public bool boosted;
    public Transform SP;
    public Rigidbody ThrowingItem;
    public GameObject Player;
    public float ThrowDistence;
    public bool HasItem = false;
    //Rigidbody ItemInstance;
    //public Rigidbody ItemInstance;


    // Update is called once per frame

    private void Start()
    {
        RunEnergy = 10f;
    }
    void Update()
    {
         if (Input.GetKeyDown(KeyCode.Escape))
        {
            Application.Quit();
        }

        float x = Input.GetAxis("Horizontal");
        float z = Input.GetAxis("Vertical");

        Vector3 move = transform.right * x + transform.forward * z;
        controller.Move(move * speed * Time.deltaTime);

        if (Input.GetKeyDown(KeyCode.LeftShift) && RunEnergy > 0)
        {
            run = true;
        }
        if (Input.GetKeyUp(KeyCode.LeftShift) || RunEnergy <= 0)
        {
            run = false;
        }

        if (run == true)
        {
            controller.Move(move * RSpeed * Time.deltaTime);
            RunEnergy = RunEnergy - Time.deltaTime;

        }
        if (run == false && RunEnergy < 10f)
        {
            RunEnergy = RunEnergy + Time.deltaTime;
        }
        


        if (HasItem == true && Input.GetKeyDown(KeyCode.Mouse0))
        {
            Rigidbody projectileInstance;
            projectileInstance = Instantiate(ThrowingItem, SP.position, SP.rotation) as Rigidbody;
            projectileInstance.AddForce(SP.transform.forward * ThrowDistence);
            projectileInstance.useGravity = true;
            HasItem = false;

        }

    }

    private void OnCollisionEnter(Collision other)
    {
        if (other.gameObject.tag == "dog")
        {
            Debug.Log("you've been caught");
            SceneManager.LoadScene("SampleScene");
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "WinObject")
        {
            Debug.Log("you win");
            SceneManager.LoadScene("SampleScene");
        }
        /*if (other.gameObject.tag == "dog")
        {
            Debug.Log("GOT YOU");
        }*/
        if (other.gameObject.tag == "pickUp")
        {
            Destroy(other.gameObject);
        /*    Rigidbody ItemInstance;
            ItemInstance = Instantiate(ThrowingItem, SP.position, SP.rotation) as Rigidbody;
            ItemInstance.transform.parent = transform;
            ItemInstance.useGravity = false;*/
            HasItem = true;
     /*       if (Input.GetKeyDown(KeyCode.Mouse0))
            {
                Destroy(ItemInstance);
            }*/
        }
        if (other.gameObject.tag == "CNip")
        {
            Destroy(other.gameObject);
            boosted = true;
            RunEnergy = 10;
            
        }

        if (HasItem == true && Input.GetKeyDown(KeyCode.Mouse0))
        {
/*            Rigidbody projectileInstance;
            projectileInstance = Instantiate(ThrowingItem, SP.position, SP.rotation) as Rigidbody;
            projectileInstance.AddForce(SP.localPosition * ThrowDistence);
            projectileInstance.useGravity = true;*/
            HasItem = false;
        }
        

    }
}