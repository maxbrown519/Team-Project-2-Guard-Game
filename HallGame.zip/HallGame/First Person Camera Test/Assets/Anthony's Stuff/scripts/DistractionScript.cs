﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DistractionScript : MonoBehaviour
{

    //Use to switch between Force Modes

    Rigidbody rb;





    void Start()
    {
        //You get the Rigidbody component you attach to the GameObject
        Destroy(gameObject, 8);


    }

    void Update()
    {

    }

}
