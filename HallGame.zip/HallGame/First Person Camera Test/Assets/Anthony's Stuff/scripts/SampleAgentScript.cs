﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class SampleAgentScript : MonoBehaviour
{
    public Transform target;
    public Transform target2;
    public Transform target3;
    public Transform target4;
    public Transform target5;
    public Transform target6;
    public Transform target7;
    public Transform target8;

    public Transform HideingSpace;
    public Transform DistractionTarget;
    public Transform PlayerTarget;
    public GameObject Vacum;
    public GameObject player;
    public GameObject distraction;

    public bool T1 = false;
    public bool T2 = false;
    public bool T3 = false;
    public bool T4 = false;
    public bool T5 = false;
    public bool T6 = false;
    public bool T7 = false;

    public bool distracted = false;
    public bool PlayerSpoted = false;

    public bool fear;
//    public bool distractionFound = false;
    NavMeshAgent agent;
    // Start is called before the first frame update
    void Start()
    {
        agent = GetComponent<NavMeshAgent>();
    }

    // Update is called once per frame
    void Update()
    {
        distraction = GameObject.Find("Dog_Toy Variant(Clone)");
        if (Vacum.GetComponentInChildren<switchScript>().feared == true)
        {
            fear = true;
        } else if (Vacum.GetComponentInChildren<switchScript>().feared == false)
        {
            fear = false;
        }

        if (distraction != null)
        {
            DistractionTarget = distraction.transform;
        }
        if (distraction == null)
        {
            distracted = false;
            DistractionTarget = null;
        }
        if (DistractionTarget != null)
        {
            distracted = true;
        }

        if (fear == true)
        {
            agent.SetDestination(HideingSpace.position);
        }
        if (distracted == true && fear == false)
        {
            agent.SetDestination(DistractionTarget.position);
        }
        if (PlayerSpoted == true && distracted == false && fear == false)
        {
            player = GameObject.Find("FPSPlayer");
            PlayerTarget = player.transform;
            agent.SetDestination(PlayerTarget.position);
        }
        if (PlayerSpoted == false && distracted == false && fear == false)
        {
            if (T1 == false)
            {
                agent.SetDestination(target.position);
            }
            if (T1 == true)
            {
                agent.SetDestination(target2.position);
            }
            if (T1 == true && T2 == true)
            {
                agent.SetDestination(target3.position);
            }
            if (T1 && T2 && T3 == true)
            {
                agent.SetDestination(target4.position);
            }
            if (T1 && T2 && T3 && T4 == true)
            {
                agent.SetDestination(target5.position);
            }
            if (T1 && T2 && T3 && T4 && T5 == true)
            {
                agent.SetDestination(target6.position);
            }
            if (T1 && T2 && T3 && T4 && T5 && T6 == true)
            {
                agent.SetDestination(target7.position);
            }
            if (T1 && T2 && T3 && T4 && T5 && T6 && T7 == true)
            {
                agent.SetDestination(target8.position);
            }
        }
        

    }

    private void OnCollisionEnter(Collision other)
    {
        if (other.gameObject.tag =="distraction")
        {
            Waiting();
            Destroy(other.gameObject);
            distracted = false;
            DistractionTarget = null;
        }
    }

    IEnumerable Waiting()
    {
        yield return new WaitForSeconds(4);
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Player")
        {
            PlayerSpoted = true;
        }
        if (other.gameObject.tag == "target1")
        {
            T1 = true;
        }
        if (other.gameObject.tag == "target2")
        {
            T2 = true;
        }
        if (other.gameObject.tag == "target3")
        {
            T3 = true;
        }
        if (other.gameObject.tag == "target4")
        {
            T4 = true;
        }
        if (other.gameObject.tag == "target5")
        {
            T5 = true;
        }
        if (other.gameObject.tag == "target6")
        {
            T6 = true;
        }
        if (other.gameObject.tag == "target7")
        {
            T7 = true;
        }
        if (other.gameObject.tag == "FinalTarget")
        {
            T1  = false;
            T2  = false;
            T3  = false;
            T4 = false;
            T5 = false;
            T6 = false;
            T7 = false;
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.gameObject.tag == "Player")
        {
                Waiting();
                PlayerSpoted = false;
        }
    }


}
