﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class SampleAgentScript : MonoBehaviour
{
    //sets points for the dog to walk to
    public Transform target;
    public Transform target2;
    public Transform target3;
    public Transform target4;
    public Transform target5;
    public Transform target6;
    public Transform target7;
    public Transform target8;
    //animator
    Animator anima;
    //refrences player distractions and if it is feared or not
    public Transform HideingSpace;
    public Transform DistractionTarget;
    public Transform PlayerTarget;
    public GameObject Vacum;
    public GameObject player;
    public GameObject distraction;
    // tracks which locations it's been to
    public bool T1 = false;
    public bool T2 = false;
    public bool T3 = false;
    public bool T4 = false;
    public bool T5 = false;
    public bool T6 = false;
    public bool T7 = false;

    public bool distracted = false;
    public bool PlayerSpoted = false;

    //feild of view
    public Transform Player;
    public float MaxAngle;
    public float MaxRadius;
    bool IsInFov = false;

    public bool fear;
//    public bool distractionFound = false;
    NavMeshAgent agent;
    // Start is called before the first frame update
    void Start()
    {
        agent = GetComponent<NavMeshAgent>();
        anima = gameObject.GetComponent<Animator>();
    }

    //field of view

    private void OnDrawGizmos()
    {
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, MaxRadius);
        Vector3 FovLine1 = Quaternion.AngleAxis(MaxAngle, transform.up) * transform.forward * MaxRadius;
        Vector3 FovLine2 = Quaternion.AngleAxis(-MaxAngle, transform.up) * transform.forward * MaxRadius;
        Gizmos.color = Color.blue;

        Gizmos.DrawRay(transform.position, FovLine1);
        Gizmos.DrawRay(transform.position, FovLine2);


        if (!IsInFov)
            Gizmos.color = Color.green;
        Gizmos.DrawRay(transform.position, (Player.position - transform.position).normalized *MaxRadius);

        Gizmos.color = Color.black;
        Gizmos.DrawRay(transform.position, transform.forward * MaxRadius);
    }

    /*public static bool inFov(Transform checkObject, Transform goal, float MaxAngle, float MaxRadius)
    {
        Collider[] overlaps = new Collider[10];
        int count = Physics.OverlapSphereNonAlloc(checkObject.position, MaxRadius, overlaps);

        for (int i = 0; i < count +1; i++)
        {
            if (overlaps[i] != null)
            {
                if (overlaps[i].transform == goal)
                {
                    Vector3 directionBetween = (goal.position - checkObject.position).normalized;
                    directionBetween.y *= 0;

                    float angle = Vector3.Angle(checkObject.forward, directionBetween);

                    if (angle <= MaxAngle)
                    {
                        Ray ray = new Ray(checkObject.position, goal.position - checkObject.position);
                        RaycastHit hit;
                        if (Physics.Raycast(ray, out hit, MaxRadius))
                        {
                            if (hit.transform == goal)
                                return true;
                        }
                    }
                }

            }
        }

       return false;
    }*/

    // Update is called once per frame
    void Update()
    {
        //PlayerSpoted = IsInFov;
        anima.SetFloat("State", 1);
        distraction = GameObject.Find("Dog_Toy Variant(Clone)");
        if (Vacum.GetComponentInChildren<switchScript>().feared == true)
        {
            fear = true;
        } else if (Vacum.GetComponentInChildren<switchScript>().feared == false)
        {
            fear = false;
        }

        if (distraction != null)
        {
            DistractionTarget = distraction.transform;
        }
        if (distraction == null)
        {
            distracted = false;
            DistractionTarget = null;
        }
        if (DistractionTarget != null)
        {
            distracted = true;
        }

        if (fear == true)
        {
            agent.SetDestination(HideingSpace.position);
        }
        if (distracted == true && fear == false)
        {
            agent.SetDestination(DistractionTarget.position);
        }
        if (PlayerSpoted == true && distracted == false && fear == false)
        {
            player = GameObject.Find("FPSPlayer");
            PlayerTarget = player.transform;
            agent.SetDestination(PlayerTarget.position);
        }
        if (PlayerSpoted == false && distracted == false && fear == false)
        {
            if (T1 == false)
            {
                agent.SetDestination(target.position);
            }
            if (T1 == true)
            {
                agent.SetDestination(target2.position);
            }
            if (T1 == true && T2 == true)
            {
                agent.SetDestination(target3.position);
            }
            if (T1 && T2 && T3 == true)
            {
                agent.SetDestination(target4.position);
            }
            if (T1 && T2 && T3 && T4 == true)
            {
                agent.SetDestination(target5.position);
            }
            if (T1 && T2 && T3 && T4 && T5 == true)
            {
                agent.SetDestination(target6.position);
            }
            if (T1 && T2 && T3 && T4 && T5 && T6 == true)
            {
                agent.SetDestination(target7.position);
            }
            if (T1 && T2 && T3 && T4 && T5 && T6 && T7 == true)
            {
                agent.SetDestination(target8.position);
            }
        }

        //IsInFov = inFov(transform, Player, MaxAngle, MaxRadius);
        /*if (IsInFov == true)
        {
            //play dog sound here
            PlayerSpoted = true;
        } else if (IsInFov == false)
        {
            PlayerSpoted = false;
        }*/
        

    }

    private void OnCollisionEnter(Collision other)
    {
        if (other.gameObject.tag =="distraction")
        {
            Destroy(other.gameObject, 3);
            distracted = false;
            DistractionTarget = null;
        }
        if (other.gameObject.tag == "Player")
        {
            //load gameover screen
            //Play dog sound here
        }
    }



    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject == player)
        {
            PlayerSpoted = true;
        }
        if (other.gameObject.tag == "target1")
        {
            T1 = true;
        }
        if (other.gameObject.tag == "target2")
        {
            T2 = true;
        }
        if (other.gameObject.tag == "target3")
        {
            T3 = true;
        }
        if (other.gameObject.tag == "target4")
        {
            T4 = true;
        }
        if (other.gameObject.tag == "target5")
        {
            T5 = true;
        }
        if (other.gameObject.tag == "target6")
        {
            T6 = true;
        }
        if (other.gameObject.tag == "target7")
        {
            T7 = true;
        }
        if (other.gameObject.tag == "FinalTarget")
        {
            T1 = false;
            T2 = false;
            T3 = false;
            T4 = false;
            T5 = false;
            T6 = false;
            T7 = false;
        }
    }

    private void OnTriggerExit(Collider other)
    {
        if (other.gameObject == player)
        {
                PlayerSpoted = false;
        }
    }


}
