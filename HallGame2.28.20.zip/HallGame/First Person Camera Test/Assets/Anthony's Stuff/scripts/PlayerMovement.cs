﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerMovement : MonoBehaviour
{
    public CharacterController controller;
    public float speed = 12f;
    public float RSpeed = 18f;
    public float RunEnergy;
    public bool run;
    public bool boosted;
    public Transform SP;
    public Rigidbody ThrowingItem;
    public GameObject Player;
    public float ThrowDistence;
    public bool HasItem = false;
    //Rigidbody ItemInstance;
    //public GameObject ItemInstance;
    //energy bar
    public SprintBarScript sprintbar;
    public float MRunEnergy;



    // Update is called once per frame

    private void Start()
    {
        RunEnergy = 10;
        MRunEnergy = 10;
        sprintbar.SetMaxSprint(MRunEnergy);
    }
    void Update()
    {
        sprintbar.SetSprint(RunEnergy);
         if (Input.GetKeyDown(KeyCode.Escape))
        {
            Application.Quit();
        }

        float x = Input.GetAxis("Horizontal");
        float z = Input.GetAxis("Vertical");

        Vector3 move = transform.right * x + transform.forward * z;
        controller.Move(move * speed * Time.deltaTime);

        if (Input.GetKeyDown(KeyCode.LeftShift) && RunEnergy > 0)
        {
            run = true;
        }
        if (Input.GetKeyUp(KeyCode.LeftShift) || RunEnergy <= 0)
        {
            run = false;
        }

        if (run == true)
        {
            controller.Move(move * RSpeed * Time.deltaTime);
            RunEnergy -=  Time.deltaTime;

        }
        if (run == false && RunEnergy < 10f)
        {
            RunEnergy += Time.deltaTime;
        }
        if (run == false && RunEnergy > 10f)
        {
            RunEnergy = 10f;
        }



        if (HasItem == true && Input.GetKeyDown(KeyCode.Mouse0))
        {
            Rigidbody projectileInstance;
            projectileInstance = Instantiate(ThrowingItem, SP.position, SP.rotation) as Rigidbody;
            projectileInstance.AddForce(SP.transform.forward * ThrowDistence);
           //ItemInstance.useGravity = true;
           // Destroy(ItemInstance);
            HasItem = false;
            

        }

    }

    private void OnCollisionEnter(Collision other)
    {
        if (other.gameObject.tag == "dog")
        {
            Debug.Log("you've been caught");
            SceneManager.LoadScene("SampleScene");
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "WinObject")
        {
            //play cat sound
            Debug.Log("you win");
            SceneManager.LoadScene("SampleScene");
        }
        /*if (other.gameObject.tag == "dog")
        {
            Debug.Log("GOT YOU");
        }*/
        if (other.gameObject.tag == "pickUp" && HasItem == false)
        {
          
            Destroy(other.gameObject);
            //Rigidbody ItemInstance;
            //ItemInstance = Instantiate(ThrowingItem, SP.position, SP.rotation) as Rigidbody;
            //ItemInstance.transform.parent = transform;
            //ItemInstance.useGravity = false;
            HasItem = true;
        }
        if (other.gameObject.tag == "CNip")
        {
            //play cat sound
            Destroy(other.gameObject);
            boosted = true;
            RunEnergy = 10;
            
        }
   

    }
}